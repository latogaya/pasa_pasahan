package com.seller.inventory;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;


public class Product implements Parcelable {

    private String mName;
    private String mDescription;
    private String mType;
    private String mSize;
    private String mBrand;


    private double mPrice;

    public Product(String name, String description, double price, String type, String size, String brand) {
        mName = name;
        mDescription = description;
        mPrice = price;
        mType = type;
        mSize = size;
        mBrand = brand;
    }

    protected Product(Parcel in) {
        mName = in.readString();
        mDescription = in.readString();
        mPrice = in.readDouble();
        mType = in.readString();
        mSize = in.readString();
        mBrand = in.readString();

    }

    public static final Creator<Product> CREATOR = new Creator<Product>() {
        @Override
        public Product createFromParcel(Parcel in) {
            return new Product(in);
        }

        @Override
        public Product[] newArray(int size) {
            return new Product[size];
        }
    };

    public String getName() {
        return mName;
    }

    public String getDescription() {
        return mDescription;
    }
    public String getmType() {
        return mType;
    }

    public String getmSize() {
        return mSize;
    }
    public String getmBrand() {
        return mBrand;
    }
    public double getPrice() {
        return mPrice;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mName);
        parcel.writeString(mDescription);
        parcel.writeString(mType);
        parcel.writeString(mSize);
        parcel.writeString(mBrand);
        parcel.writeDouble(mPrice);
    }
}
