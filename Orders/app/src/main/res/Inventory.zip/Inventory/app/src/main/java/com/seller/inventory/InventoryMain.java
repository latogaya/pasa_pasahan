package com.seller.inventory;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class InventoryMain extends AppCompatActivity {

    private static final int REQUEST_CODE_ADD_PRODUCT = 1;

    private ListView mProductsListView;
    private List<Product> mProducts;
    private ProductAdapter mProductAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        mProductsListView = findViewById(R.id.productsListView);
        mProducts = new ArrayList<>();
        mProductAdapter = new ProductAdapter(this, R.layout.inventory_recycler_view, mProducts);
        mProductsListView.setAdapter(mProductAdapter);

        Button sortButton = findViewById(R.id.sortButton);
        sortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sortProducts();
            }
        });

        // Find the remove button in the layout
        Button removeButton = findViewById(R.id.deleteButton);

        // Set a click listener on the remove button
        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the selected item position in the ListView
                int position = mProductsListView.getCheckedItemPosition();
                if (position != ListView.INVALID_POSITION) {
                    // Remove the item from the List and update the adapter
                    mProducts.remove(position);
                    mProductAdapter.notifyDataSetChanged();
                }
            }
        });

        // Set an item click listener on the ListView to handle item selection
        mProductsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                // Set the item as checked in the ListView
                mProductsListView.setItemChecked(position, true);
            }
        });

        // Find the transaction button in the layout
        Button transactionButton = findViewById(R.id.transactionButton);

        // Set a click listener on the transaction button
        transactionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the selected item position in the ListView
                int position = mProductsListView.getCheckedItemPosition();
                if (position != ListView.INVALID_POSITION) {
                    // Get the selected product from the List
                    Product selectedProduct = mProducts.get(position);
                    // Start the TransactionDetails activity with the selected product
                    Intent intent = new Intent(InventoryMain.this, TransactionDetails.class);
                    intent.putExtra("product", selectedProduct);
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD_PRODUCT && resultCode == RESULT_OK) {
            // Get the new product from the Intent
            Product newProduct = data.getParcelableExtra("product");

            // Add the new product to the list and update the adapter
            mProducts.add(newProduct);
            mProductAdapter.notifyDataSetChanged();
        }
    }

    private void sortProducts() {
        // Sort the products list by name using a Comparator
        Collections.sort(mProducts, new Comparator<Product>() {
            @Override
            public int compare(Product product1, Product product2) {
                return product1.getName().compareToIgnoreCase(product2.getName());
            }
        });

        // Notify the adapter that the data set has changed
        mProductAdapter.notifyDataSetChanged();
    }
}

