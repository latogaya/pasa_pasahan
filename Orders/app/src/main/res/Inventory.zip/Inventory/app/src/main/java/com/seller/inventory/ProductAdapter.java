package com.seller.inventory;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
import java.util.Locale;

public class ProductAdapter extends ArrayAdapter<Product> {
    private Context mContext;
    private int mResource;
    private List<Product> mProducts;

    public ProductAdapter(Context context, int resource, List<Product> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
        mProducts = objects;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            view = inflater.inflate(mResource, parent, false);
        }

        Product product = getItem(position);

        TextView nameTextView = view.findViewById(R.id.productBrand);
        nameTextView.setText(product.getmBrand());

        TextView descriptionTextView = view.findViewById(R.id.productName);
        descriptionTextView.setText(product.getName());

        TextView priceTextView = view.findViewById(R.id.productPrice);
        priceTextView.setText(String.format(Locale.getDefault(), "$%.2f", product.getPrice()));

        TextView sizeTextView = view.findViewById(R.id.productSize);
        descriptionTextView.setText(product.getName());

        TextView typeTextView = view.findViewById(R.id.productType);
        descriptionTextView.setText(product.getName());

        return view;
    }
}