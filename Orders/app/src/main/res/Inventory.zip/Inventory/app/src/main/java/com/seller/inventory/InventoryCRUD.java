package com.seller.inventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InventoryCRUD extends AppCompatActivity {

    private EditText mNameEditText;
    private EditText mDescriptionEditText;
    private EditText mPriceEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_crud);

        mNameEditText = findViewById(R.id.productnameEdit);
        mDescriptionEditText = findViewById(R.id.productidEdit);
        mPriceEditText = findViewById(R.id.productpriceEdit);

        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the product information from the EditTexts
                String name = mNameEditText.getText().toString();
                String description = mDescriptionEditText.getText().toString();
                double price = Double.parseDouble(mPriceEditText.getText().toString());

                // Create a new Product object
                Product newProduct = new Product(name, description, price);

                // Create an Intent to return the new product to the InventoryMain activity
                Intent intent = new Intent();
                intent.putExtra("product", newProduct);
                setResult(RESULT_OK, intent);

                // Finish the activity and return to the InventoryMain activity
                finish();
            }
        });
    }
}
